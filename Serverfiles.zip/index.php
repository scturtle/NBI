<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  position: relative;
  overflow: hidden;
  background-color: #120F12;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  border-radius: 0px;
  color: black;
}

.topnav a.active {
  background-color: #3F4945;
  border-radius: 0px;
  color: #BCC4BC;
}

.topnav-centered a {
  float: none;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.topnav-right {
  float: right;
}

/* Responsive navigation menu (for mobile devices) */
@media screen and (max-width: 600px) {
  .topnav a, .topnav-right {
    float: none;
    display: block;
  }
  
  .topnav-centered a {
    position: relative;
    top: 0;
    left: 0;
    transform: none;
  }
}

/* Popup container - can be anything you want */
.popup {
  position: relative;
  display: inline-block;
  cursor: pointer;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

/* The actual popup */
.popup .popuptext {
  visibility: hidden;
  width: 160px;
  background-color: #262B27;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 8px 0;
  position: absolute;
  z-index: 1;
  bottom: 125%;
  left: 50%;
  margin-left: -80px;
}

/* Popup arrow */
/*
.popup .popuptext::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  margin-left: -5px;
  border-width: 5px;
  border-style: solid;
  border-color: #12120F transparent transparent transparent;
}
*/

/* Toggle this class - hide and show the popup */
.popup .show {
  visibility: visible;
  -webkit-animation: fadeIn 1s;
  animation: fadeIn 1s;
}

/* Add animation (fade in the popup) */
@-webkit-keyframes fadeIn {
  from {opacity: 0;} 
  to {opacity: 1;}
}

@keyframes fadeIn {
  from {opacity: 0;}
  to {opacity:1 ;}
}
</style>
</head>
<body>

<!-- Top navigation -->
<div class="topnav">

  <!-- Centered link -->
  <div class="topnav-centered">
    <!--<a href="../" class="active">Refresh Page</a>-->
    <a href="../">Refresh Page</a>
  </div>
  
  <!-- Left-aligned links (default) -->
  <a href="links.php">File List</a>
  
  <!-- Right-aligned links -->
  <div class="topnav-right">
    <a href="https://github.com/mrdude2478/TinWoo/releases">Tinwoo</a>
  </div>  
</div>
</body>
</html>
<?php
date_default_timezone_set('Europe/London');
	//to do - add icons based on file types: https://css-tricks.com/snippets/php/display-styled-directory-contents/
	
	//TinWoo - set to true if tinwoo is set to encode urls automatically
	$TINWOOENCODE = true;

	// Redirection
	$Folder = "../"; //actually this just jumps back one page - but since we have this page in root, it will just refresh.
	$title = "<a href='".$Folder."'>Refresh Page</a>";
	
	// TITLE OF PAGE
	$title2 = "Switch Games List";
	
	// Root url for our site files such as images and scripts
	$SiteFiles = "site_files";

	// ADD SPECIFIC FILES YOU WANT TO IGNORE HERE
	$ignore_file_list = array( ".htaccess", "Thumbs.db", ".DS_Store", "index.php", ".ftpquota", "index.php-json" );
	
	// ADD SPECIFIC FOLDERS YOU WANT TO IGNORE HERE
	$ignore_folder_list = array( $SiteFiles, "90dns", "admin", "henlo", "pihole");
	
	// ADD SPECIFIC FILE EXTENSIONS YOU WANT TO IGNORE HERE, EXAMPLE: array('psd','jpg','jpeg')
	$ignore_ext_list = array( "bak", "js", "php", "txt" );
	
	// SORT BY
	$sort_by = "name_asc"; // options: name_asc, name_desc, date_asc, date_desc
	
	// ICON URL
	$icon_url = $SiteFiles . "/images/myicons.png";
	
	// TOGGLE SUB FOLDERS, SET TO false IF YOU WANT OFF
	$toggle_sub_folders = true;
	
	// Still to do - Add code later to count the amount of files we have
	$count = 0;
	
	
// SET TITLE BASED ON FOLDER NAME, IF NOT SET ABOVE
if( !$title2 ) { $title2 = cleanTitle(basename(dirname(__FILE__))); }
?>
<form>
<head>
	<title><?php echo $title2; ?></title>
	<script src="<?php echo $SiteFiles; ?>/jquery.min.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Lato:700,400,300,300italic,700italic" rel="stylesheet" type="text/css" />
	<style>
		*, *:before, *:after { -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; }
		body {
	font-family: "Lato", "HelveticaNeue-Light", "Helvetica Neue Light", "Helvetica Neue", Helvetica, Arial, "Lucida Grande", sans-serif;
	font-weight: 400;
	font-size: 14px;
	line-height: 18px;
	/*background-color: #000000;
	background-image: url(<?php echo $SiteFiles; ?>/images/congruent_outline.png);*/
	background: rgb(0,0,0);
	background: linear-gradient(180deg, rgba(0,0,0,1) 0%, rgba(46,46,46,1) 50%, rgba(0,0,0,1) 100%);
	background-repeat: repeat;
}
		.wrap { max-width: 800px; margin: 10px auto; background: #C4C9C6; padding: 10px; box-shadow: 0 0 4px #ccc; }
		h1 { text-align: center; margin: 40px 0; font-size: 28px; font-weight: bold; color: #FAF9F9; }
		h2 { text-align: center; font-size: 14px; font-weight: bold; color: #666; }
		a { color: #0053FF; text-decoration: none; } a:hover { color: #4400FF; text-decoration: none; }
		.block .img { width: 40px; height: 40px; display: block; float: left; margin-right: 10px; background: transparent url(<?php echo $icon_url; ?>) no-repeat 0 0; }
		.block .date { margin-top: 4px; margin-bottom: 4px; font-size: 80%; color: #666; }
		.block a { display: block; padding: 10px 15px; transition: all 0.35s; }
		.block a:hover { text-decoration: none; background: #efefef; }
		.dir { background-position: 0px 0 !important; }
		.nsp { background-position: -40px 0 !important; }
		.nsz { background-position: -80px 0 !important; }
		.xci { background-position: -120px 0 !important; }
		.xcz { background-position: -160px 0 !important; }
		.sub { margin-left: 20px; margin-right: 0px; border-left: solid 1px #C4C9C6; border-right: solid 1px #C4C9C6; border-top: solid 1px #AFB1B2; border-bottom: solid 0px #AFB1B2;display: none; }	
	</style>
</form>
</head>
<body>
<!--<h1><?php echo $title ?></h1>-->
<div class="wrap">
<?php

// FUNCTIONS TO MAKE THE MAGIC HAPPEN, BEST TO LEAVE THESE ALONE
function cleanTitle($title2)
{
	return ucwords( str_replace( array("-", "_"), " ", $title2) );
}

function getFileExt($filename) 
{
	return substr( strrchr( $filename,'.' ),1 );
}

function format_size($file) 
{
	$bytes = filesize($file);
	if ($bytes < 1024) return $bytes.'b';
	elseif ($bytes < 1048576) return round($bytes / 1024, 2).'kb';
	elseif ($bytes < 1073741824) return round($bytes / 1048576, 2).'mb';
	elseif ($bytes < 1099511627776) return round($bytes / 1073741824, 2).'gb';
	else return round($bytes / 1099511627776, 2).'tb';
}


// SHOW THE MEDIA BLOCK
function display_block( $file )
{
	global $ignore_file_list, $ignore_folder_list, $ignore_ext_list, $TINWOOENCODE, $Host, $count;
	
	$file_ext = getFileExt($file);
	if( !$file_ext AND is_dir($file)) { $file_ext = "dir"; }
	if(in_array($file, $ignore_file_list)) { return; }
	if(in_array($file_ext, $ignore_ext_list)) { return; }
	if(in_array($file, $ignore_folder_list)) { return; }
	
	echo "<div class=\"block\">";
	if ($TINWOOENCODE) {
		echo "<a href=\"$file\" class=\"$file_ext\">";
	}
	else {
		echo "<a href=\"" . rawurlencode($file) . "\" class=\"$file_ext\">";
	}
	echo "	<div class=\"img $file_ext\">&nbsp;</div>";
	echo "	<div class=\"name\">\n";
	echo "		<div class=\"file\">" . basename($file) . "</div>\n";
	
	if (format_size($file) == "4kb") {
		echo "		<div class=\"date\">Last modified: " .  date("D. F jS, Y", filemtime($file)) . "</div>\n";
	}
	else {
		echo "		<div class=\"date\">Size: " . format_size($file) . ", Last modified: " .  date("D. F jS, Y", filemtime($file)) . "</div>\n";
	}
	echo "	</div>\n";
	echo "	</a>\n";
	echo "</div>";
}


// RECURSIVE FUNCTION TO BUILD THE BLOCKS
function build_blocks( $items, $folder )
{
	global $ignore_file_list, $ignore_ext_list, $sort_by, $toggle_sub_folders, $count;
	$objects = array();
	$objects['directories'] = array();
	$objects['files'] = array();
	
	foreach($items as $c => $item)
	{
		if( $item == ".." OR $item == ".") {
			continue;
		}
	
		// IGNORE FILE
		if(in_array($item, $ignore_file_list)) { 
			continue;
		}
	
		if( $folder )
		{
			$item = "$folder/$item";
		}

		$file_ext = getFileExt($item);
		
		// IGNORE EXT
		if(in_array($file_ext, $ignore_ext_list)){
			continue;
		}
		
		// DIRECTORIES
		if( is_dir($item) ) 
		{
			$objects['directories'][] = $item;
			continue;
		}
		
		// FILE DATE
		$file_time = date("U", filemtime($item));
		
		// FILES
		$objects['files'][$file_time . "-" . $item] = $item;
		
	}
	
	foreach($objects['directories'] as $c => $file)
	{
		display_block( $file );
		
		if($toggle_sub_folders)
		{
			$sub_items = (array) scandir( $file );
			if( $sub_items )
			{
				echo "<div class='sub' data-folder=\"$file\">";
				build_blocks( $sub_items, $file );
				echo "</div>";
			}
		}
	}
	
	// SORT BEFORE LOOP
	if( $sort_by == "date_asc" ) { ksort($objects['files']); }
	elseif( $sort_by == "date_desc" ) { krsort($objects['files']); }
	elseif( $sort_by == "name_asc" ) { natsort($objects['files']); }
	elseif( $sort_by == "name_desc" ) { arsort($objects['files']); }
	else {asort($objects['files']);}
	
	foreach($objects['files'] as $t => $file)
	{
		$fileExt = getFileExt($file);
		if(in_array($file, $ignore_file_list)) { 
			continue;
		}
		if(in_array($fileExt, $ignore_ext_list)) {
			continue;
		}
		display_block( $file );
	}
}

// GET THE BLOCKS STARTED, FALSE TO INDICATE MAIN FOLDER
$items = scandir( dirname(__FILE__) );
build_blocks( $items, false );
?>

<?php if($toggle_sub_folders) { ?>
<script>
	$(document).ready(function() 
	{
		$("a.dir").click(function(e)
		{
		 	$('.sub[data-folder="' + $(this).attr('href') + '"]').slideToggle();
			e.preventDefault();
		});
	
	});
</script>
<?php } ?>
</div>

<?php
global $count;
//echo "<p><center>File Total: $count</center></p>"
?>
<html>
<h2><div class="popup" onclick="myFunction()">About
  <span class="popuptext" id="myPopup">Coded By MrDude</span>
</div></h2>
<script>
// When the user clicks on div, open the popup
function myFunction() {
  var popup = document.getElementById("myPopup");
  popup.classList.toggle("show");
}
</script>
</html>