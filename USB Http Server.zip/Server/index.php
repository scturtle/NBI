<html>
	<style>
		body {
			margin: 0;
			font-family: Arial, Helvetica, sans-serif;
		}
  /* Add a black background color to the top navigation */
    .topnav {
    	position: relative;
      background-color: #120F12;
      overflow: hidden;
      height: 45px;
    }

    /* Style the links inside the navigation bar */
    .topnav a {
    	margin-left: 48%;
      color: #f2f2f2;
      position: absolute;
      font-size: 17px;
      text-align: center;
  		text-decoration: none;
  		padding: 14px 16px;
  		padding: 15px;
    }

    /* Change the color of links on hover */
    .topnav a:hover {
      background-color: #ddd;
      border-radius: 0px;
      color: black;
    }

    /* Add a color to the active/current link */
    .topnav a.active {
      background-color: #3F4945;
      border-radius: 5px;
      color: #BCC4BC;
    }

		*, *:before, *:after { -moz-box-sizing: border-box; -webkit-box-sizing: border-box; box-sizing: border-box; }
		body {
	font-family: "Lato", "HelveticaNeue-Light", "Helvetica Neue Light", "Helvetica Neue", Helvetica, Arial, "Lucida Grande", sans-serif;
	font-weight: 400;
	font-size: 14px;
	line-height: 18px;
	/*background-color: #000000;
	background-image: url(<?php echo $SiteFiles; ?>/images/congruent_outline.png);*/
	background: rgb(0,0,0);
	background: linear-gradient(180deg, rgba(0,0,0,1) 0%, rgba(46,46,46,1) 50%, rgba(0,0,0,1) 100%);
	background-repeat: repeat;
}
		.wrap { max-width: 800px; margin: 10px auto; background: #C4C9C6; padding: 10px; box-shadow: 0 0 4px #ccc; }
		h1 { text-align: center; margin: 20px 0; font-size: 20px; font-weight: bold; color: #FAF9F9; }
		h2 { text-align: center; font-size: 14px; font-weight: bold; color: #666; }
		a { color: #0053FF; text-decoration: none; } a:hover { color: #4400FF; text-decoration: none; }
		.block .img { width: 40px; height: 40px; display: block; float: left; margin-right: 10px; background: transparent url(<?php echo $icon_url; ?>) no-repeat 0 0; }
		.block .date { margin-top: 4px; margin-bottom: 4px; font-size: 80%; color: #666; }
		.block a { display: block; padding: 10px 15px; transition: all 0.35s; }
		.block a:hover { text-decoration: none; background: #efefef; }
		.dir { background-position: 0px 0 !important; }
		.nsp { background-position: -40px 0 !important; }
		.nsz { background-position: -80px 0 !important; }
		.xci { background-position: -120px 0 !important; }
		.xcz { background-position: -160px 0 !important; }
		.sub { margin-left: 20px; margin-right: 0px; border-left: solid 1px #C4C9C6; border-right: solid 1px #C4C9C6; border-top: solid 1px #AFB1B2; border-bottom: solid 0px #AFB1B2;display: none; }	
	</style>
<div class="topnav">
  <a href="../">Refresh</a>
</div>
</html>

<?php
/****************************************
*		Configuration Parameters        *
****************************************/
$MOTD = "Switch Games List";			//Message that appears each time Tinfoil start and receive the file for the first time
$Redirect = "../"; //redirection page
$rootFolder = $_SERVER['DOCUMENT_ROOT'] . "../";		//The base path to use to browse files and create cache, at the moment must be a folder reachable by http client
$Folder = "Games";								//Where the games file are stored, can contain subfolders
$cacheFolder = "../Server/Server/cache/";							//the cache Folder where to store the cache file. MUST Have write permission
$cacheFile = "cache.json";								//the cached file. MUST Have write permission
$arrExtensions = ['nsp','xci','nsz', 'xcz'];		//which extensions to list 
$DBI = true;										//if true then output in html to be compatible with DBI installer
$BackColor = "#000000";								//Page Background Color
$ForeColor = "#cccccc";								//Text Color
$AltRowColor = "#222222";							//File list alternate row color
$TINWOOENCODE = true; //TinWoo - let tinwoo encode urls automatically
$Host = "/"; //just leave

error_reporting (E_ALL ^ E_NOTICE);
/****************************************
*		Headers for Json File           *
****************************************/
if(!$DBI) {
	header("Content-Type: application/json");
	header('Content-Disposition: filename="main.json"');
}

/****************************************
*				MAIN		            *
****************************************/

//If Cached file exits then send it
if(file_exists($rootFolder.$cacheFolder.$cacheFile) && !isset($_GET['reset'])){
	readfile($rootFolder.$cacheFolder.$cacheFile);
	unlink($rootFolder.$cacheFolder.$cacheFile); //delete cache automatically when page loads.

//Else recalculate, save and send cache file
}else{
	set_time_limit(0);			//Try to avoid Timeout for big collection of files
	$aar = recursiveDirectoryIterator($Folder, $Host);
	$aarr['total'] = count($aar);
	asort($aar);				//Try to Sort
	$aarr['files'] = $aar;
	if(trim($MOTD) != "") $aarr['success'] = $MOTD;

	//check if you have write access to the chache folder
	//If not write access then stream out the json as is
	if (!is_dir($rootFolder.$cacheFolder) or !is_writable($rootFolder.$cacheFolder)) {
		if ($DBI) {
			echo createHtml($aar);
		} else {
			echo json_encode($aarr);
		}
		
	} else {
		//Save file and stream it out
		if ($DBI) {
			file_put_contents($rootFolder.$cacheFolder.$cacheFile ,createHtml($aar));
		} else {
			file_put_contents($rootFolder.$cacheFolder.$cacheFile ,json_encode($aarr));
		}
		
		readfile($rootFolder.$cacheFolder.$cacheFile);
	}
}

/**
* @param array $arr		The compiled array results from directory scan
* @return string		The full Html page 
*/
function createHtml($arr = null) {
	
	global $rootFolder;
	global $MOTD;
	global $BackColor;
	global $ForeColor;
	global $AltRowColor;
	global $Folder;
	global $Redirect;
	
	$htmlPage = "<html><head><style type=\"text/css\">
		/* General styles */
		BODY {
			background-color:".$BackColor.";
			color:".$ForeColor.";
			font-family:sans-serif;
		}
		
		A {
			color: ".$ForeColor.";
			text-decoration: none;
		}

		A:hover {
			text-decoration: none;
		}
		
		table {
			width:65%;
			margin: auto;
			font-size:small;
		}
		tr:nth-child(even) {
            background-color: ".$AltRowColor.";
        }
	</style>
	<div style='text-align: center'>
	<title>$MOTD</title>
</head>
<body>
	<center><h1>Files Found: ".count($arr)."</h1></center>
	<table>
	";
	
	//Here get the files and create rows
	foreach ( $arr as $file ) {
		
       $htmlPage = $htmlPage . '
	   <tr>
		<td style="text-align:left; font-size: 14px; width:88%;"><a href="' . $file['url'] . '">' . $file['name'] . '</a><br /></td>
		<td style="text-align:right; text-align-last: right;"> '.sprintf("%0.2f", (($file['size'] /1024) / 1024)).' MB </td>
	   </tr>
		';	// info->isFile ()) {
	}

	$htmlPage = $htmlPage . '
	</table>
	<br><br>
</body></html>';

		return $htmlPage;
}


/**
* @param string $directory
* @param array $files
* @return array
*/

function recursiveDirectoryIterator ($directory = null, $host, $files = array()) {
    
	global $rootFolder;
	global $arrExtensions;
	global $DBI;
	global $TINWOOENCODE;
	
	$iterator = new \DirectoryIterator ( $Folder.$directory );

    foreach ( $iterator as $info ) {
        if ($info->isFile ()) {
			
			if( in_array($info->getExtension(),$arrExtensions) ){

				$url = $host . str_replace($rootFolder, "", $info->getPathname());
				
				//Try to get a correct file size
				$fsize = $info->getSize();

				//very slow but the only way that works on all platforms.
				if($fsize < 0 ) {
					//$fsize = array_change_key_case(get_headers($url, 1),CASE_LOWER);
					if ( strcasecmp($fsize[0], 'HTTP/1.1 200 OK') != 0 ) {
						$fsize = $fsize['content-length'][1]; }
					else {
						$fsize = $fsize['content-length'];
					}

				}
				
				if ($DBI) {
					if ($TINWOOENCODE){
						$files [] = [
						//'url'=> $host . rawurlencode(str_replace($rootFolder, "", $info->getPathname())),
						'url'=> $host . str_replace($rootFolder, "", $info->getPathname()),
						'url'=> $host . str_replace("\\", "/", $info->getPathname()), //fix windows paths
						'name'=> $info->getFilename(),
						'size'=> $fsize
						];
					}
					else{
						$files [] = [
						'url'=> $host . rawurlencode(str_replace($rootFolder, "", $info->getPathname())),
						'url'=> $host . str_replace("\\", "/", $info->getPathname()), //fix windows paths
						//'url'=> $host . str_replace($rootFolder, "", $info->getPathname()),
						'name'=> $info->getFilename(),
						'size'=> $fsize
						];
					}
					
				} else {
					
					$files [] = [
						'url'=> $host . str_replace($rootFolder, "", $info->getPathname()).'#'.rawurlencode(str_replace('#','',$info->getFilename())),
						'size'=>$info->getSize()
					];
					
				}
			}

        } elseif (!$info->isDot ()) {

            $list = recursiveDirectoryIterator(
                        $directory.DIRECTORY_SEPARATOR.$info->__toString (), $host
            );
            if(!empty($files))
                $files = array_merge_recursive($files, $list);
            else {
                $files = $list;
            }
        }
    }
    return $files;
}
?>